﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace restuarant_management_system.Migrations
{
    /// <inheritdoc />
    public partial class Initialmarch : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DateOfAvailability",
                table: "Tables");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "Tables");

            migrationBuilder.DropColumn(
                name: "Price",
                table: "Tables");

            migrationBuilder.RenameColumn(
                name: "RestaurantId",
                table: "Tables",
                newName: "TableNumber");

            migrationBuilder.AddColumn<int>(
                name: "Capacity",
                table: "Tables",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "IsAvailable",
                table: "Tables",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Capacity",
                table: "Tables");

            migrationBuilder.DropColumn(
                name: "IsAvailable",
                table: "Tables");

            migrationBuilder.RenameColumn(
                name: "TableNumber",
                table: "Tables",
                newName: "RestaurantId");

            migrationBuilder.AddColumn<DateTime>(
                name: "DateOfAvailability",
                table: "Tables",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "Tables",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<decimal>(
                name: "Price",
                table: "Tables",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);
        }
    }
}
