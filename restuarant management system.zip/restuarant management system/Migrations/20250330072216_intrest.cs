﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace restuarant_management_system.Migrations
{
    /// <inheritdoc />
    public partial class intrest : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TableReservation_Tables_TableId",
                table: "TableReservation");

            migrationBuilder.DropForeignKey(
                name: "FK_TableReservation_Users_CustomerId",
                table: "TableReservation");

            migrationBuilder.DropIndex(
                name: "IX_TableReservation_CustomerId",
                table: "TableReservation");

            migrationBuilder.DropIndex(
                name: "IX_TableReservation_TableId",
                table: "TableReservation");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_TableReservation_CustomerId",
                table: "TableReservation",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_TableReservation_TableId",
                table: "TableReservation",
                column: "TableId");

            migrationBuilder.AddForeignKey(
                name: "FK_TableReservation_Tables_TableId",
                table: "TableReservation",
                column: "TableId",
                principalTable: "Tables",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TableReservation_Users_CustomerId",
                table: "TableReservation",
                column: "CustomerId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
