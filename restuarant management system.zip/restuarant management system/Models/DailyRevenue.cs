﻿namespace restuarant_management_system.Models
{
    public class DailyRevenue
    {
        public int Id { get; set; }

        public DateTime Date { get; set; }

        public decimal TotalRevenue { get; set; }
    }
}
