﻿using System.ComponentModel.DataAnnotations;

namespace restuarant_management_system.Models
{
    public class Table
    {
        public int Id { get; set; }

        [Required]
        public int TableNumber { get; set; }

        [Required]
        public int Capacity { get; set; }

        public bool IsAvailable { get; set; }
    }
}
