﻿using System.ComponentModel.DataAnnotations;

namespace restuarant_management_system.Models
{
    public class TableReservation
    {
        public int Id { get; set; }

        public int CustomerId { get; set; }


        public int TableId { get; set; }


        public DateTime ReservationTime { get; set; }

        public string Status { get; set; }
    }
}
