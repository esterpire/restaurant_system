﻿using System.ComponentModel.DataAnnotations;

namespace restuarant_management_system.Models
{
    public class InventoryItem
    {
        public int Id { get; set; }

        [Required]
        public string ItemName { get; set; }

        [Required]
        public int Quantity { get; set; }

        public string Unit { get; set; }  // e.g., kg, liter, piece
    }
}
