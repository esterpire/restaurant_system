﻿using restuarant_management_system.Enums;
using System.ComponentModel.DataAnnotations;

namespace restuarant_management_system.Models
{
    public class Payment
    {
        public int Id { get; set; }

        [Required]
        public int OrderId { get; set; }

        public Order Order { get; set; }

        [Required]
        public decimal Amount { get; set; }

        public PaymentMethod Method { get; set; }

        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;
    }
}
