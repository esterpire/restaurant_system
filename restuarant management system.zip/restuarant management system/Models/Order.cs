﻿using restuarant_management_system.Enums;
using System.ComponentModel.DataAnnotations;

namespace restuarant_management_system.Models
{
    public class Order
    {
        public int Id { get; set; }

        [Required]
        public int CustomerId { get; set; }

        public User Customer { get; set; }

        public List<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

        public OrderStatus Status { get; set; }

        public DateTime OrderTime { get; set; } = DateTime.UtcNow;
    }
}
