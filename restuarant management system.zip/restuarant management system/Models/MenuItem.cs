﻿using System.ComponentModel.DataAnnotations;

namespace restuarant_management_system.Models
{
    public class MenuItem
    {
        public int Id { get; set; }

        [Required]
        public string? Name { get; set; }

        [Required]
        public int Price { get; set; }

        public string? Description { get; set; }

        public bool IsAvailable { get; set; }
    }
}
