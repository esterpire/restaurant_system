﻿namespace restuarant_management_system.Enums
{
    public enum OrderStatus
    {
        Pending,
        Completed
    }
}
