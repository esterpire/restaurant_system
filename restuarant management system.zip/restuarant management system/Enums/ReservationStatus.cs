﻿namespace restuarant_management_system.Enums
{
    public enum ReservationStatus
    {
        Pending = 0,
        Approved = 1,
        Rejected = 2
    }
}
