﻿namespace restuarant_management_system.Enums
{
    public enum PaymentMethod
    {
        Cash,
        Card
    }
}
