﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using restuarant_management_system.DTOS;
using restuarant_management_system.Enums;
using restuarant_management_system.Models;

namespace restuarant_management_system.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WaiterApController : ControllerBase
    {
        private readonly AppDbContext _context;

        public WaiterApController(AppDbContext context)
        {
            _context = context;
        }

        // --- Order Management ---
        // Retrieves all orders, including customer info and each order's items with menu details.
        [HttpGet]
        [Route("GetOrders")]
        public async Task<IActionResult> GetOrders()
        {
            try
            {
                var orders = await _context.Order
                    .Include(o => o.OrderItems) // Include Order Items
                    .Select(o => new
                    {
                        OrderId = o.Id,
                        OrderTime = o.OrderTime, // Format DateTime
                        Status = (o.Status == OrderStatus.Completed) ? 1 : 0,
                        Quantity = _context.OrderItem
                             .Where(oi => oi.OrderId == o.Id)
                             .Sum(oi => oi.Quantity)
                    })
                    .ToListAsync();

                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Internal Server Error", error = ex.Message });
            }
        }



        // Creates a new order. The request body should include the CustomerId and OrderItems.
        [HttpPost("TakeOrder")]
        public async Task<IActionResult> TakeOrder([FromBody] Order order)
        {
            try
            {
                // Set the order time (this could be set by the client as well)
                order.OrderTime = DateTime.UtcNow;
                _context.Order.Add(order);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetOrders), new { id = order.Id }, order);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        // Updates the order status (for example, Pending, Completed, etc.).
        [HttpPost]
        [Route("UpdateOrderStatus")]
        public async Task<IActionResult> UpdateOrderStatus([FromBody] UpdateOrderStatusRequest request)
        {
            try
            {
                // Find the order by ID
                var order = await _context.Order.FindAsync(request.OrderId);
                if (order == null)
                {
                    return NotFound(new { message = "Order not found" });
                }

                // Update the order status
                order.Status = (OrderStatus)request.Status; // 0 = Pending, 1 = Completed
                await _context.SaveChangesAsync();

                return Ok(new { message = "Order status updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Internal Server Error", error = ex.Message });
            }
        }


        // --- Billing & Payment ---
        // Generates the bill for an order by summing up (MenuItem.Price * OrderItem.Quantity) for each order item.
        [HttpGet("GenerateBill/{orderId}")]
        public async Task<IActionResult> GenerateBill(int orderId)
        {
            try
            {
                var order = await _context.Order
             .Include(o => o.OrderItems)
                 .ThenInclude(oi => oi.MenuItem)
             .FirstOrDefaultAsync(o => o.Id == orderId);
                if (order == null)
                    return NotFound();

                decimal totalAmount = order.OrderItems.Sum(oi => oi.MenuItem.Price * oi.Quantity);
                return Ok(new { OrderId = orderId, TotalAmount = totalAmount });

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

     
        // --- Table Viewing (Read-Only) ---
        // Returns the list of tables available in the restaurant.
        [HttpGet]
        [Route("GetTables")]
        public async Task<IActionResult> GetTables()
        {
            try
            {
                var tables = await _context.Tables.ToListAsync();
                return Ok(tables);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        [HttpGet("GenerateBillmenu")]
        public async Task<IActionResult> GenerateBillmenu()
        {
            try
            {
                var menuItems = await _context.MenuItems
                    .Select(item => new
                    {
                        item.Price,
                        item.Name
                    })
                    .ToListAsync();

                return Ok(menuItems);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }


        [HttpGet("GetOrdersWithStatus")]
        public async Task<IActionResult> GetOrdersWithStatus()
        {
            try
            {
                var orders = await _context.Order
                    .Include(o => o.OrderItems)
                        .ThenInclude(oi => oi.MenuItem)
                    .Select(o => new
                    {
                        OrderId = o.Id,
                        OrderTime = o.OrderTime,
                        PaymentStatus = o.Status == OrderStatus.Pending ? "Pending" : "Completed",
                        Items = o.OrderItems.Select(oi => new
                        {
                            MenuItemName = oi.MenuItem.Name,
                            Price = oi.MenuItem.Price,
                            Quantity = oi.Quantity
                        }).ToList()
                    })
                    .ToListAsync();

                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }


    }
}
