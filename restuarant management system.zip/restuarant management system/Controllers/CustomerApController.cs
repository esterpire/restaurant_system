﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using restuarant_management_system.DTOS;
using restuarant_management_system.Enums;
using restuarant_management_system.Models;

namespace restuarant_management_system.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerApController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CustomerApController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("GetMenu")]
        public async Task<IActionResult> GetMenu()
        {
            try
            {
                return Ok(await _context.MenuItems.ToListAsync());

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        // --- Place Order ---
        [HttpPost("PlaceOrder")]
        public async Task<IActionResult> PlaceOrder([FromBody] SinglerequestDto orderDto)
        {
            try
            {
                if (orderDto.CustomerId == 0 || orderDto.MenuItemId == 0)
                {
                    return BadRequest("Invalid customer or menu item.");
                }

                // Fetch Customer
                var customer = await _context.Users.FindAsync(orderDto.CustomerId);
                if (customer == null)
                {
                    return NotFound("Customer not found.");
                }

                // Fetch Menu Item
                var menuItem = await _context.MenuItems.FindAsync(orderDto.MenuItemId);
                if (menuItem == null || !menuItem.IsAvailable)
                {
                    return NotFound("Menu item not found or unavailable.");
                }

                // Create Order
                var order = new Order
                {
                    CustomerId = orderDto.CustomerId,
                    Status = OrderStatus.Pending,
                    OrderItems = new List<OrderItem>
            {
                new OrderItem
                {
                    MenuItemId = orderDto.MenuItemId,
                    Quantity = orderDto.Quantity
                }
            }
                };

                _context.Order.Add(order);
                await _context.SaveChangesAsync();

                return Ok(new { message = "Order placed successfully!", orderId = order.Id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        //Order status
        [HttpGet]
        [Route("CustOrderStatus")]
        public async Task<IActionResult> CustOrderStatus(int userId)
        {
            try
            {
                var orders = await _context.Order
             .Where(o => o.CustomerId == userId)
             .OrderByDescending(o => o.OrderTime)
             .Select(o => new
             {
                 OrderId = o.Id,
                 Status = (o.Status == OrderStatus.Completed) ? 1 : 0,
                 StatusText = o.Status.ToString(),
                 OrderTime = o.OrderTime,
                 Quantity = _context.OrderItem
                     .Where(oi => oi.OrderId == o.Id)
                     .Sum(oi => oi.Quantity) // Sum quantity for this order
             })
             .ToListAsync();

                if (!orders.Any())
                {
                    return NotFound(new { message = "No orders found" });
                }

                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Internal Server Error", error = ex.Message });
            }
        }

        [HttpPost]
        [Route("BookTable")]
        public async Task<IActionResult> BookTable([FromBody] Table request)
        {
            try
            {
                // Check if the table exists
                var table = await _context.Tables.FindAsync(request.Id);
                if (table == null)
                {
                    return NotFound(new { message = "Table not found" });
                }

                // Check if the table is already reserved
                var existingReservation = await _context.TableReservation
                    .FirstOrDefaultAsync(r => r.TableId == request.Id && r.Status == ReservationStatus.Approved.ToString());

                if (existingReservation != null)
                {
                    return BadRequest(new { message = "Table is already reserved. Please choose another table." });
                }

                // Create a new reservation with Pending status
                var newReservation = new TableReservation
                {
                    TableId = request.Id,
                    ReservationTime = DateTime.UtcNow, // Replace with the actual reservation time from frontend
                    Status = ReservationStatus.Pending.ToString(),
                };

                _context.TableReservation.Add(newReservation);

                // Mark table as unavailable


                await _context.SaveChangesAsync();

                return Ok(new { message = "Reservation booked successfully!" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Internal Server Error", error = ex.Message });
            }
        }

        [HttpGet]
        [Route("Tablecustomer")]
        public async Task<IActionResult> GetTables()
        {
            try
            {
                return Ok(await _context.Tables.ToListAsync());

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        [HttpGet("Paymentmenu")]
        public async Task<IActionResult> Paymentmenu(int userId)
        {
            try
            {
                // Fetch orders related to the logged-in user
                var customerOrders = await _context.Order
                    .Where(o => o.CustomerId == userId)
                    .SelectMany(o => o.OrderItems)
                    .Select(oi => new
                    {
                        Name = oi.MenuItem.Name, // Menu item name
                        Price = oi.MenuItem.Price // Price per item (without quantity multiplication)
                    })
                    .ToListAsync();

                if (!customerOrders.Any())
                {
                    return NotFound(new { message = "No payment details found for this customer." });
                }

                return Ok(customerOrders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

    }
}
