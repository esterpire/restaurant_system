﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using restuarant_management_system.Enums;
using restuarant_management_system.Models;

namespace restuarant_management_system.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagerApController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ManagerApController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("MenuItemsGet")]
        public async Task<IActionResult> GetMenuItems()
        {
            try
            {
                return Ok(await _context.MenuItems.ToListAsync());

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }


        [HttpPost("AddMenu")]
        public async Task<IActionResult> AddMenuItem([FromBody] MenuItem item)
        {
            try
            {
                _context.MenuItems.Add(item);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetMenuItems), new { id = item.Id }, item);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        [HttpPut]
        [Route("UpdateMenu/{id}")]
        public async Task<IActionResult> UpdateMenuItem(int id, [FromBody] MenuItem item)
        {
            try
            {
                var existing = await _context.MenuItems.FindAsync(id);
                if (existing == null)
                    return NotFound();

                existing.Name = item.Name;
                existing.Price = item.Price;
                existing.Description = item.Description;
                existing.IsAvailable = item.IsAvailable;

                await _context.SaveChangesAsync();
                return Ok(existing);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }


        }

        [HttpGet]
        [Route("DeleteMenu/{id}")]
        public async Task<IActionResult> DeleteMenuItem(int id)
        {
            try
            {
                var item = await _context.MenuItems.FindAsync(id);
                if (item == null)
                    return NotFound();

                _context.MenuItems.Remove(item);
                await _context.SaveChangesAsync();
                return NoContent();
            }

            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        // --- Inventory Management ---
        [HttpGet]
        [Route("GetInventory")]
        public async Task<IActionResult> GetInventory()
        {
            try
            {
                return Ok(await _context.InventoryItem.ToListAsync());

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("AddInventoryItems")]
        public async Task<IActionResult> AddInventoryItem([FromBody] InventoryItem item)
        {
            try
            {
                _context.InventoryItem.Add(item);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetInventory), new { id = item.Id }, item);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        [HttpPut]
        [Route("UpdateInventory/{id}")]
        public async Task<IActionResult> UpdateInventoryItem(int id, [FromBody] InventoryItem item)
        {
            try
            {
                var existing = await _context.InventoryItem.FindAsync(id);
                if (existing == null)
                    return NotFound();

                existing.ItemName = item.ItemName;
                existing.Quantity = item.Quantity;
                existing.Unit = item.Unit;
                await _context.SaveChangesAsync();
                return Ok(existing);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("DeleteInventory/{id}")]
        public async Task<IActionResult> DeleteInventoryItem(int id)
        {
            try
            {
                var item = await _context.InventoryItem.FindAsync(id);
                if (item == null)
                    return NotFound();

                _context.InventoryItem.Remove(item);
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        //Table code 

        [HttpGet]
        [Route("GetTables")]
        public async Task<IActionResult> GetTables()
        {
            try
            {
                return Ok(await _context.Tables.ToListAsync());

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("AddTable")]
        public async Task<IActionResult> AddTable([FromBody] Table table)
        {
            try
            {
                _context.Tables.Add(table);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetTables), new { id = table.Id }, table);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        [HttpPut]
        [Route("UpdateTable/{id}")]
        public async Task<IActionResult> UpdateTable(int id, [FromBody] Table table)
        {
            try
            {
                var existing = await _context.Tables.FindAsync(id);
                if (existing == null)
                    return NotFound();

                existing.TableNumber = table.TableNumber;
                existing.Capacity = table.Capacity;
                existing.IsAvailable = table.IsAvailable;
                await _context.SaveChangesAsync();
                return Ok(existing);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        [HttpGet]
        [Route("DeleteTable/{id}")]
        public async Task<IActionResult> DeleteTable(int id)
        {
            try
            {
                var table = await _context.Tables.FindAsync(id);
                if (table == null)
                    return NotFound();

                _context.Tables.Remove(table);
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        //DailyRevenue code
        [HttpGet]
        [Route("GetDailyRevenue")]
        public async Task<IActionResult> GetDailyRevenue()
        {
            try
            {
                return Ok(await _context.DailyRevenue.ToListAsync());

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("AddDailyRevenue")]
        public async Task<IActionResult> AddDailyRevenue([FromBody] DailyRevenue revenue)
        {
            try
            {
                revenue.Date = DateTime.UtcNow.Date;
                _context.DailyRevenue.Add(revenue);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetDailyRevenue), new { id = revenue.Id }, revenue);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }

        }

        //Handle Daily revinue

        [HttpGet("ManagerdailyRevenue")]
        public async Task<IActionResult> ManagerdailyRevenue()
        {
            try
            {
                var orders = await _context.Order
                    .Include(o => o.OrderItems)
                        .ThenInclude(oi => oi.MenuItem)
                    .Select(o => new
                    {
                        OrderId = o.Id,
                        OrderTime = o.OrderTime,
                        Items = o.OrderItems.Select(oi => new
                        {
                            MenuItemName = oi.MenuItem.Name,
                            Price = oi.MenuItem.Price,
                            Quantity = oi.Quantity
                        }).ToList()
                    })
                    .ToListAsync();

                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }
    }
}
