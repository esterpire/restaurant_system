﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using restuarant_management_system.Models;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    public AuthController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<User>>> GetUsers()
    {
        return await _context.Users.ToListAsync();
    }
    [HttpPost("signup")]
    public async Task<IActionResult> Signup([FromBody] AuthRequest request)
    {
        if (await _context.Users.AnyAsync(u => u.Email == request.Email))
        {
            return BadRequest(new { message = "Email already exists" });
        }

        // Ensure role is valid
        var validRoles = new List<string> { "Customer", "Waiter", "Manager" };
        if (!validRoles.Contains(request.Role))
        {
            return BadRequest(new { message = "Invalid role" });
        }

        var user = new User
        {
            Email = request.Email,
            Password = request.Password, // ⚠️ Stored in plain text (not recommended)
            Role = request.Role,
            CreatedAt = DateTime.UtcNow
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Registration successful", role = user.Role });
    }



    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto request)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == request.Email);

        if (user == null || user.Password != request.Password) // Direct comparison
        {
            return BadRequest(new { message = "Invalid email or password" });
        }

        return Ok(new
        {
            message = "Login successful",
            userId = user.Id,
            email = user.Email,
            role = user.Role
        });
    }


    private bool VerifyPassword(string password, string hash)
    {
        return password == hash;
    }
}