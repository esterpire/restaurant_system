﻿namespace restuarant_management_system.DTOS
{
    public class SinglerequestDto
    {
        public int CustomerId { get; set; }
        public int MenuItemId { get; set; }

        public int Quantity { get; set; } = 1;
    }
}
