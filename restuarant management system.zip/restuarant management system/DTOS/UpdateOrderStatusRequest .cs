﻿namespace restuarant_management_system.DTOS
{
    public class UpdateOrderStatusRequest
    {
        public int OrderId { get; set; }
        public int Status { get; set; }
    }
}
