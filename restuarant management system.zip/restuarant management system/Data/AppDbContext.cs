﻿using Microsoft.EntityFrameworkCore;
using restuarant_management_system.Models;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Restaurant> Restaurants { get; set; }
    public DbSet<Table> Tables { get; set; }
    public DbSet<BookTable> BookTables { get; set; }
    public DbSet<User> Users { get; set; }
    public DbSet<MenuItem> MenuItems { get; set; }
    public DbSet<Order> Order { get; set; }
    public DbSet<OrderItem> OrderItem { get; set; }
    public DbSet<TableReservation> TableReservation { get; set; }
    public DbSet<Payment> Payment { get; set; }
    public DbSet<InventoryItem> InventoryItem { get; set; }
    public DbSet<DailyRevenue> DailyRevenue { get; set; }











    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

     
    }
}
