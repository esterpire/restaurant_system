﻿using System.ComponentModel.DataAnnotations;

namespace Resturantweb.Models
{
    public class TableViewModel
    {
        public int Id { get; set; }

        [Required]
        public int TableNumber { get; set; }

        [Required]
        public int Capacity { get; set; }

        public bool IsAvailable { get; set; }
    }
}
