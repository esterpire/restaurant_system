﻿using System.ComponentModel.DataAnnotations;

namespace Resturantweb.Models
{
    public class InventoryItemViewModel
    {
        public int Id { get; set; }

        [Required]
        public string ItemName { get; set; }

        [Required]
        public int Quantity { get; set; }

        public string Unit { get; set; }  // e.g., kg, liter, piece
    }
}
