﻿using System.ComponentModel.DataAnnotations;

namespace Resturantweb.Models
{
    public class OrderItemsViewModel
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public int MenuItemId { get; set; }
        public int Quantity { get; set; }
        public int price { get; set; }
        public int CustomerId { get; set; }
        public int? status { get; set; }
        public DateTime OrderTime { get; set; } = DateTime.UtcNow;

        // Add this to match API response
        public string MenuItemName { get; set; }

    }
}
