﻿namespace Resturantweb.Models
{
    public class SingleOrderRequestModel
    {
        public int CustomerId { get; set; }
        public int MenuItemId { get; set; }

        public int Quantity { get; set; } = 1;
    }
}
