﻿namespace Resturantweb.Models
{
    public class LoginDto
    {
        public string? Email { get; set; }
        public string? Role { get; set; }

        public int? UserId { get; set; }
    }
}
