﻿namespace Resturantweb.Models
{
    public class Updateorderstatsumodel
    {
        public int OrderId { get; set; }
        public int Status { get; set; }
    }
}
