﻿using Newtonsoft.Json;

namespace Resturantweb.Models
{
    public class PaymentViewModel
    {
        public int OrderId { get; set; }
        public DateTime OrderTime { get; set; }
        public string PaymentStatus { get; set; }

        [JsonProperty("items")]
        public List<OrderItemsViewModel> menu { get; set; } = new List<OrderItemsViewModel>();


    }
}
