﻿$(document).ready(function () {
    $('.delete-menu-btn').on('click', function () {
        //var roleId = String($(this).data('role-id')).trim();
        var menuid = $(this).attr('data-menu-id');
        var rowToDelete = $(this).closest('tr');
        console.log("menuid:", menuid);
        if (confirm("Are you sure you want to delete this role?")) {
            $.ajax({
                type: 'GET',
                url: `/Manager/Deletemenuitem/${menuid}`,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response.success) {
                        rowToDelete.remove();
                        //alert(response.message);
                        /*location.reload();*/
                    } else {
                        alert("Failed to delete role: " + response.message);
                    }
                },
                error: function (xhr, status, error) {
                    alert("An error occurred: " + xhr.responseText);
                }
            });
        }
    });

    // Open Update Modal
    $('.update-menu-btn').on('click', function () {
        var menuId = $(this).data('menu-id');
        var menuName = $(this).closest('tr').find('td:eq(1)').text();
        var menuPrice = $(this).closest('tr').find('td:eq(2)').text();
        var menuDescription = $(this).closest('tr').find('td:eq(3)').text();
        var isAvailable = $(this).closest('tr').find('td:eq(4)').text().trim() === "Available";

        // Populate modal fields
        $('#menuId').val(menuId);
        $('#menuName').val(menuName);
        $('#menuPrice').val(menuPrice);
        $('#menuDescription').val(menuDescription);
        $('#menuIsAvailable').prop('checked', isAvailable);

        // Show the modal
        $('#updateMenuModal').modal('show');
    });

    // Handle Save Changes
    $('#saveMenuChanges').on('click', function () {
        var menuId = $('#menuId').val();
        var menuName = $('#menuName').val().trim();
        var menuPrice = $('#menuPrice').val();
        var menuDescription = $('#menuDescription').val().trim();
        var isAvailable = $('#menuIsAvailable').is(':checked');

        const menuData = {
            Id: menuId,
            Name: menuName,
            Price: parseFloat(menuPrice),
            Description: menuDescription,
            IsAvailable: isAvailable
        };

        // AJAX Request to Update Menu
        $.ajax({
            type: 'PUT',
            url: `/Manager/Updatemenu/${menuId}`,
            contentType: "application/json",
            data: JSON.stringify(menuData),
            success: function (response) {
                if (response.success) {
                    let row = $(`button[data-menu-id="${menuId}"]`).closest('tr');
                    row.find('td:eq(1)').text(menuName);
                    row.find('td:eq(2)').text(menuPrice);
                    row.find('td:eq(3)').text(menuDescription);
                    row.find('td:eq(4)').text(isAvailable ? "Available" : "Not Available");

                    $('#updateMenuModal').modal('hide');
                } else {
                    alert("Error: " + response.message);
                }
            },
            error: function (xhr) {
                alert("An error occurred: " + xhr.responseText);
            }
        });
    });

    //Inventory Management
    $('.delete-invnt-btn').on('click', function () {
        //var roleId = String($(this).data('role-id')).trim();
        var invntid = $(this).attr('data-invnt-id');
        var rowToDelete = $(this).closest('tr');
        console.log("menuid:", invntid);
        if (confirm("Are you sure you want to delete this role?")) {
            $.ajax({
                type: 'GET',
                url: `/Manager/Deleteinventry/${invntid}`,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response.success) {
                        rowToDelete.remove();
                        //alert(response.message);
                        /*location.reload();*/
                    } else {
                        alert("Failed to delete role: " + response.message);
                    }
                },
                error: function (xhr, status, error) {
                    alert("An error occurred: " + xhr.responseText);
                }
            });
        }
    });

    // Open Update Modal
    $('.update-invnt-btn').on('click', function () {
        var invntId = $(this).data('invnt-id');
        var itemName = $(this).closest('tr').find('td:eq(1)').text().trim();
        var quantity = $(this).closest('tr').find('td:eq(2)').text().trim();
        var unit = $(this).closest('tr').find('td:eq(3)').text().trim();

        // Populate modal fields
        $('#invntId').val(invntId);
        $('#itemName').val(itemName);
        $('#quantity').val(quantity);
        $('#unit').val(unit);

        // Show the modal
        $('#updateInventoryModal').modal('show');
    });

    // Handle Save Changes
    $('#saveInventoryChanges').on('click', function () {
        var invntId = $('#invntId').val();
        var itemName = $('#itemName').val().trim();
        var quantity = parseInt($('#quantity').val());
        var unit = $('#unit').val().trim();

        const inventoryData = {
            Id: invntId,
            ItemName: itemName,
            Quantity: quantity,
            Unit: unit
        };

        // AJAX Request to Update Inventory Item
        $.ajax({
            type: 'PUT',
            url: `/Manager/Updateinvntry/${invntId}`,
            contentType: "application/json",
            data: JSON.stringify(inventoryData),
            success: function (response) {
                if (response.success) {
                    let row = $(`button[data-invnt-id="${invntId}"]`).closest('tr');
                    row.find('td:eq(1)').text(itemName);
                    row.find('td:eq(2)').text(quantity);
                    row.find('td:eq(3)').text(unit);

                    $('#updateInventoryModal').modal('hide');
                } else {
                    alert("Error: " + response.message);
                }
            },
            error: function (xhr) {
                alert("An error occurred: " + xhr.responseText);
            }
        });
    });


    //Table Management
    $('.delete-table-btn').on('click', function () {
        //var roleId = String($(this).data('role-id')).trim();
        var tableid = $(this).attr('data-table-id');
        var rowToDelete = $(this).closest('tr');
        console.log("menuid:", tableid);
        if (confirm("Are you sure you want to delete this role?")) {
            $.ajax({
                type: 'GET',
                url: `/Manager/Tabledelete/${tableid}`,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response.success) {
                        rowToDelete.remove();
                        //alert(response.message);
                        /*location.reload();*/
                    } else {
                        alert("Failed to delete role: " + response.message);
                    }
                },
                error: function (xhr, status, error) {
                    alert("An error occurred: " + xhr.responseText);
                }
            });
        }
    });

    $('.update-table-btn').on('click', function () {
        var tableId = $(this).data('table-id');
        var row = $(this).closest('tr');

        var tableNumber = row.find('td:eq(1)').text().trim();
        var capacity = row.find('td:eq(2)').text().trim();
        var isAvailableText = row.find('td:eq(3)').text().trim();
        var isAvailable = isAvailableText === "Available";

        // Populate modal fields
        $('#tableId').val(tableId);
        $('#tableNumber').val(tableNumber);
        $('#capacity').val(capacity);
        $('#isAvailable').prop('checked', isAvailable);

        // Show the modal
        $('#updateTableModal').modal('show');
    });

    // Handle table Save Changes
    $('#saveTableChanges').on('click', function () {
        var tableId = $('#tableId').val();
        var tableNumber = $('#tableNumber').val().trim();
        var capacity = parseInt($('#capacity').val());
        var isAvailable = $('#isAvailable').is(':checked');

        const tableData = {
            Id: tableId,
            TableNumber: tableNumber,
            Capacity: capacity,
            IsAvailable: isAvailable
        };

        // AJAX Request to Update Table
        $.ajax({
            type: 'PUT',
            url: `/Manager/TableUpdate/${tableId}`,
            contentType: "application/json",
            data: JSON.stringify(tableData),
            success: function (response) {
                if (response.success) {
                    let row = $(`button[data-table-id="${tableId}"]`).closest('tr');
                    row.find('td:eq(1)').text(tableNumber);
                    row.find('td:eq(2)').text(capacity);
                    row.find('td:eq(3)').text(isAvailable ? "Available" : "Not Available");

                    $('#updateTableModal').modal('hide');
                } else {
                    alert("Error: " + response.message);
                }
            },
            error: function (xhr) {
                alert("An error occurred: " + xhr.responseText);
            }
        });
    });

    //Place an order
    var orderedItems = JSON.parse(localStorage.getItem("orderedItems")) || [];

    $(".place-order-btn").each(function () {
        var menuItemId = $(this).data("menu-id");

        // ✅ If order exists in localStorage, disable the button
        if (orderedItems.includes(menuItemId)) {
            $(this).prop("disabled", true).text("Order has been placed");
        }
    });

    $(".place-order-btn").on("click", function () {
        var menuItemId = $(this).data("menu-id");
        var button = $(this);

        $.ajax({
            url: "/Customer/PlaceOrder",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ MenuItemId: menuItemId }),
            success: function (response) {
                // ✅ Update UI and save to localStorage
                button.prop("disabled", true).text("Order has been placed");

                // Save ordered item in localStorage
                orderedItems.push(menuItemId);
                localStorage.setItem("orderedItems", JSON.stringify(orderedItems));
            },
            error: function (xhr) {
                alert("Error: " + xhr.responseText);
            }
        });
    });

    $(document).ready(function () {
        $(".update-order-btn").each(function () {
            var $button = $(this);
            var orderStatus = $button.data("order-status"); // Get status from data attribute

            if (orderStatus === 1) { // If order is completed
                $button.prop("disabled", true).text("Order has updated");
            }
        });
    });

    $(document).on("click", ".update-order-btn", function () {
        var $button = $(this); // Store button reference
        var orderId = $button.data("order-id"); // Get order ID

        $.ajax({
            url: "/Waiter/UpdateOrder",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ OrderId: orderId, Status: 1 }), // Sending an object
            success: function (response) {
                if (response.success) {
                    $button.prop("disabled", true).text("Order has updated");
                    location.reload();// Disable & change text
                } else {
                    alert("Error: " + response.message);
                }
            },
            error: function (xhr) {
                alert("Error: " + xhr.responseText);
            }
        });
    });

    //Custiomer table book resevations
    $(document).ready(function () {
        // Disable buttons for already booked tables on page load
        $(".reservation-table-btn").each(function () {
            var tableId = $(this).data("reservation-id");
            if (localStorage.getItem("reserved_table_" + tableId)) {
                $(this).prop("disabled", true).text("Reservation has been placed");
            }
        });
    });

    $(document).on("click", ".reservation-table-btn", function () {
        debugger;
        var $button = $(this); // Store button reference
        var tableId = $button.data("reservation-id");

        console.log("tableId", tableId);

        $.ajax({
            url: "/Customer/Bokreservation",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ Id: tableId }),
            success: function (response) {
                // Disable the button and update text
                $button.prop("disabled", true).text("Reservation has been placed");

                // Save to localStorage to persist after page reload
                localStorage.setItem("reserved_table_" + tableId, "true");
            },
            error: function (error) {
                alert(error.responseJSON?.message || "Failed to book the table.");
            }
        });
    });

});


