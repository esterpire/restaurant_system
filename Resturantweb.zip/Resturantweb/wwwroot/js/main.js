﻿$(document).ready(function () {
    $('#User').dataTable({
        "searching": true,
        "responsive": true,
        "processing": true,
        "serverSide": false,
        "filter": true
    });
});