﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Resturantweb.Models;
using System.Text;

namespace Resturantweb.Controllers
{
    public class WaiterController : Controller
    {
        private readonly HttpClient _client;
        public WaiterController(IHttpClientFactory httpClientFactory)
        {
            _client = httpClientFactory.CreateClient("MyApiClient");
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Waitertable()
        {
            try
            {
                List<TableViewModel> items = new List<TableViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"WaiterAp/GetTables");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    items = JsonConvert.DeserializeObject<List<TableViewModel>>(data);
                    return View(items);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }


        //View Order
        [HttpGet]
        public async Task<IActionResult> ViewOrder()
        {
            try
            {
                List<OrderItemsViewModel> items = new List<OrderItemsViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"WaiterAp/GetOrders");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    items = JsonConvert.DeserializeObject<List<OrderItemsViewModel>>(data);
                    return View(items);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateOrder([FromBody] Updateorderstatsumodel model)
        {
            try
            {
                

                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                var response = await _client.PostAsync($"WaiterAp/UpdateOrderStatus", content);

                if (response.IsSuccessStatusCode)
                {
                    return Json(new { success = true, message = "Order status updated successfully!" });
                }

                return Json(new { success = false, message = "Failed to update order status" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GeneerateBill()
        {
            try
            {
                List<MenuItemViewModel> items = new List<MenuItemViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"WaiterAp/GenerateBillmenu");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    items = JsonConvert.DeserializeObject<List<MenuItemViewModel>>(data);
                    return View(items);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> Handlepayment()
        {
            try
            {
                List<PaymentViewModel> items = new List<PaymentViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"WaiterAp/GetOrdersWithStatus");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    items = JsonConvert.DeserializeObject<List<PaymentViewModel>>(data);
                    return View(items);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }
    }
}
