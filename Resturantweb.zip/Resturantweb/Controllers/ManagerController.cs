﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Resturantweb.Models;
using System.Text;

namespace Resturantweb.Controllers
{
    public class ManagerController : Controller
    {
        private readonly HttpClient _client;
        public ManagerController(IHttpClientFactory httpClientFactory)
        {
            _client = httpClientFactory.CreateClient("MyApiClient");
        }
        public IActionResult Index()
        {
            return View();
        }

        //menuitems
        [HttpGet]
        public async Task<IActionResult> ViewMenuItems()
        {
            try
            {
                List<MenuItemViewModel> items = new List<MenuItemViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"ManagerAp/MenuItemsGet");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    items = JsonConvert.DeserializeObject<List<MenuItemViewModel>>(data);
                    return View(items);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        public IActionResult AddmenuItems()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddmenuItems(MenuItemViewModel request)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _client.PostAsync($"ManagerAp/AddMenu", content);
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var createdProduct = JsonConvert.DeserializeObject<MenuItemViewModel>(data);
                    return RedirectToAction("ViewMenuItems", "Manager");
                }
                return RedirectToAction("AddmenuItesm", "Manager");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }

        [HttpPut]
        public async Task<IActionResult> Updatemenu(int id, [FromBody] MenuItemViewModel model)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                var response = await _client.PutAsync($"ManagerAp/UpdateMenu/{id}", content);

                if (response.IsSuccessStatusCode)
                {
                    var updateitems = JsonConvert.DeserializeObject<MenuItemViewModel>(await response.Content.ReadAsStringAsync());
                    return Json(new { success = true, role = updateitems });
                }

                return Json(new { success = false });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> Deletemenuitem(int Id)
        {
            try
            {

                HttpResponseMessage response = await _client.GetAsync($"ManagerAp/DeleteMenu/{Id}");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var createdProduct = JsonConvert.DeserializeObject<MenuItemViewModel>(data);
                    return Json(new { success = true });
                }            
                 return Json(new { success = false });
                
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        //Inventory
        [HttpGet]
        public async Task<IActionResult> ViewInventory()
        {
            try
            {
                List<InventoryItemViewModel> inventory = new List<InventoryItemViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"ManagerAp/GetInventory");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    inventory = JsonConvert.DeserializeObject<List<InventoryItemViewModel>>(data);
                    return View(inventory);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        public IActionResult AddInventory()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddInventory(InventoryItemViewModel request)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _client.PostAsync($"ManagerAp/AddInventoryItems", content);
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var createdProduct = JsonConvert.DeserializeObject<InventoryItemViewModel>(data);
                    return RedirectToAction("ViewInventory", "Manager");
                }
                return RedirectToAction("AddInventory", "Manager");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }

        [HttpPut]
        public async Task<IActionResult> Updateinvntry(int id, [FromBody] InventoryItemViewModel model)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                var response = await _client.PutAsync($"ManagerAp/UpdateInventory/{id}", content);

                if (response.IsSuccessStatusCode)
                {
                    var updateitems = JsonConvert.DeserializeObject<InventoryItemViewModel>(await response.Content.ReadAsStringAsync());
                    return Json(new { success = true, role = updateitems });
                }

                return Json(new { success = false });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }


        [HttpGet]
        public async Task<IActionResult> Deleteinventry(int Id)
        {
            try
            {

                HttpResponseMessage response = await _client.GetAsync($"ManagerAp/DeleteInventory/{Id}");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var createdProduct = JsonConvert.DeserializeObject<InventoryItemViewModel>(data);
                    return Json(new { success = true });
                }
                return Json(new { success = false });

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        //Table code
        [HttpGet]
        public async Task<IActionResult> ViewTable()
        {
            try
            {
                List<TableViewModel> table = new List<TableViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"ManagerAp/GetTables");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    table = JsonConvert.DeserializeObject<List<TableViewModel>>(data);
                    return View(table);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        public IActionResult TableAdd()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> TableAdd(TableViewModel request)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _client.PostAsync($"ManagerAp/AddTable", content);
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var createdProduct = JsonConvert.DeserializeObject<TableViewModel>(data);
                    return RedirectToAction("ViewTable", "Manager");
                }
                return RedirectToAction("TableAdd", "Manager");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }


        [HttpPut]
        public async Task<IActionResult> TableUpdate(int id, [FromBody] TableViewModel model)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                var response = await _client.PutAsync($"ManagerAp/UpdateTable/{id}", content);

                if (response.IsSuccessStatusCode)
                {
                    var updateitems = JsonConvert.DeserializeObject<TableViewModel>(await response.Content.ReadAsStringAsync());
                    return Json(new { success = true, role = updateitems });
                }

                return Json(new { success = false });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> Tabledelete(int id)
        {
            try
            {

                HttpResponseMessage response = await _client.GetAsync($"ManagerAp/DeleteTable/{id}");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var createdProduct = JsonConvert.DeserializeObject<TableViewModel>(data);
                    return Json(new { success = true });
                }
                return Json(new { success = false });

            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }


        //DailyRevenue code

        [HttpGet]
        public async Task<IActionResult> ViewRevinue()
        {
            try
            {
                List<PaymentViewModel> table = new List<PaymentViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"ManagerAp/ManagerdailyRevenue");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    table = JsonConvert.DeserializeObject<List<PaymentViewModel>>(data);
                    return View(table);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        public IActionResult Revenue()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Revenue(DailyReviuneViewModel request)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _client.PostAsync($"ManagerAp/AddDailyRevenue", content);
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var createdProduct = JsonConvert.DeserializeObject<DailyReviuneViewModel>(data);
                    return RedirectToAction("ViewRevinue", "Manager");
                }
                return RedirectToAction("TableAdd", "Manager");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }


      

    }
}
