﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Resturantweb.Models;
using System.Text;

namespace Resturantweb.Controllers
{
    public class CustomerController : Controller
    {
        private readonly HttpClient _client;
        public CustomerController(IHttpClientFactory httpClientFactory)
        {
            _client = httpClientFactory.CreateClient("MyApiClient");
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ViewMenuItemscust()
        {
            try
            {
                List<MenuItemViewModel> items = new List<MenuItemViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"CustomerAp/GetMenu");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    items = JsonConvert.DeserializeObject<List<MenuItemViewModel>>(data);
                    return View(items);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        public IActionResult OrderPlace()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> PlaceOrder([FromBody] SingleOrderRequestModel orderDto)
        {
            try
            {
                // Get logged-in customer ID from session
                string userIdStr = HttpContext.Session.GetString("UserId");

                if (string.IsNullOrEmpty(userIdStr))
                {
                    return Unauthorized("User not logged in.");
                }

                int customerId = int.Parse(userIdStr); // Safely convert string to int

                orderDto.CustomerId = customerId; // Now safe to use



                var content = new StringContent(JsonConvert.SerializeObject(orderDto), Encoding.UTF8, "application/json");

                HttpResponseMessage response = await _client.PostAsync("CustomerAp/PlaceOrder", content);
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    return Json(new { success = true, message = "Order placed successfully!" });
                }

                return Json(new { success = false, message = "Failed to place order." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> OrderStatus()
        {
            try
            {
                List<OrderItemsViewModel> items = new List<OrderItemsViewModel>();

                // ✅ Get User ID from Session
                var userId = HttpContext.Session.GetString("UserId");

                if (string.IsNullOrEmpty(userId))
                {
                    return Unauthorized("User not logged in.");
                }

                // ✅ Call API with User ID as Query Parameter
                HttpResponseMessage response = await _client.GetAsync($"CustomerAp/CustOrderStatus?userId={userId}");

                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    items = JsonConvert.DeserializeObject<List<OrderItemsViewModel>>(data);
                    return View(items);
                }

                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }


        [HttpGet]
        public async Task<IActionResult> ViewReservation()
        {
            try
            {
                List<TableViewModel> table = new List<TableViewModel>();
                HttpResponseMessage response = await _client.GetAsync($"CustomerAp/Tablecustomer");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    table = JsonConvert.DeserializeObject<List<TableViewModel>>(data);
                    return View(table);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }


        [HttpPost]
        public async Task<IActionResult> Bokreservation([FromBody] TableReservationViewModel model)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
                var response = await _client.PostAsync("CustomerAp/BookTable", content);

                if (response.IsSuccessStatusCode)
                {
                    var result = JsonConvert.DeserializeObject<Dictionary<string, string>>(await response.Content.ReadAsStringAsync());
                    return Json(new { success = true, message = result["message"] });
                }

                return Json(new { success = false, message = "Failed to book the table." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }



        [HttpGet]
        public async Task<IActionResult> Paymentmenusitem()
        {
            try
            {
                List<MenuItemViewModel> items = new List<MenuItemViewModel>();
                // ✅ Get User ID from Session
                var userId = HttpContext.Session.GetString("UserId");

                if (string.IsNullOrEmpty(userId))
                {
                    return Unauthorized("User not logged in.");
                }
                HttpResponseMessage response = await _client.GetAsync($"CustomerAp/Paymentmenu?userId={userId}");
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    items = JsonConvert.DeserializeObject<List<MenuItemViewModel>>(data);
                    return View(items);

                }
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }
    }
}
