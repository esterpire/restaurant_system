﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Resturantweb.Models;
using System.Reflection;
using System.Text;

namespace Resturantweb.Controllers
{
    public class SecurityController : Controller
    {
        private readonly HttpClient _client;
        public SecurityController(IHttpClientFactory httpClientFactory)
        {
            _client = httpClientFactory.CreateClient("MyApiClient");
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(AuthSignupDto request)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _client.PostAsync($"Auth/Login", content);

                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var userData = JsonConvert.DeserializeObject<LoginDto>(data);

                    if (userData != null && !string.IsNullOrEmpty(userData.Role))
                    {
                        HttpContext.Session.SetString("UserId", userData.UserId.ToString());
                        HttpContext.Session.SetString("UserRole", userData.Role);
                        switch (userData.Role)
                        {
                            case "Waiter":
                                return RedirectToAction("Index", "Waiter");
                            case "Manager":
                                return RedirectToAction("Index", "Manager");
                            case "Customer":
                                return RedirectToAction("Index", "Customer");
                            default:
                                return RedirectToAction("Index", "Home"); // Fallback option
                        }
                    }
                }

                // If authentication fails, redirect back to login
                TempData["Error"] = "Invalid credentials. Please try again.";
                return RedirectToAction("Login", "Security");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }


        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SignUp(AuthSignupDto request)
        {
            try
            {
                var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
                HttpResponseMessage response = await _client.PostAsync($"Auth/Signup", content);
                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    var createdProduct = JsonConvert.DeserializeObject<AuthSignupDto>(data);                  
                    return RedirectToAction("Login", "Security");
                }              
                return RedirectToAction("SignUp", "Security");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Internal server error", error = ex.Message });
            }
        }


        public IActionResult Logout()
        {
            HttpContext.SignOutAsync();

            // Redirect to the home page or login page
            return RedirectToAction("Index", "Home");
        }
    }
}
